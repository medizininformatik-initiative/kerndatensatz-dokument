<!-- TODO:REVIEW machine-translated from the German default page -->
<!-- markdownlint-disable MD041 -->
<!-- Migrated from the Simplifier guide mii-ig-dokument-de, page
     MIIIGModulDokument/TechnischeImplementierung/FHIRProfile/Dokument-DocumentReference.page.md.
     This file is an intro note: the IG Publisher renders it above the generated artifact page
     StructureDefinition-mii-pr-dokument-dokument.html. The source page's "Uebersicht",
     "Metadaten" and "Inhalt" sections are gone, because the artifact page renders the header
     data (canonical, status, version, base) and the structure, XML and JSON views itself.
     German default page: input/intro-notes/StructureDefinition-mii-pr-dokument-dokument-intro.md -->

This profile describes the metadata of a clinical document. A detailed description and
recommendations for using the profile can be found in the
[module description](index.html).

## Mapping of the dataset to FHIR

<!-- DERIVED:bridge source=MIIIGModulDokument/TechnischeImplementierung/FHIRProfile/Dokument-DocumentReference.page.md gate=B -->
> **Written during migration — review before release.**
> The following table maps the data elements of the logical model
> [MII LM Dokument](StructureDefinition-mii-lm-dokument.html) onto the elements of this
> DocumentReference profile.
{: .ig-highlight .ig-highlight-blue}

<!-- GENERATED TABLE - mechanically produced from
     fsh-generated/resources/StructureDefinition-mii-lm-dokument.json,
     fields differential.element.short (column "Dataset"), differential.element.definition
     (column "Explanation") and differential.element.mapping[0].map (column "FHIR"),
     filtered on mapping.identity = 'mii-map-dokument' and mapping.map starting with
     'DocumentReference.'. Replaces the FQL query of the Simplifier source page; the
     IG Publisher renders a logical model's element mappings nowhere.
     REGENERATE after every change to the logical model or to the mappings.
     NOTE: the logical model carries only German short/definition texts (no translation
     extensions), so the first two columns here are machine-translated - see the
     TODO:REVIEW at the top of this file. -->

| Dataset | Explanation | FHIR |
| --- | --- | --- |
| Version-specific identifier | Version-specific unique identifier assigned to the document by the document source | `DocumentReference.masterIdentifier` |
| Version-independent identifier | Other version-independent identifier assigned to the document (e.g. by further document-processing systems) | `DocumentReference.identifier` |
| Status of the document reference | Status of this document reference (current, superseded or entered in error) | `DocumentReference.status` |
| Status of the document | Status of the underlying document (preliminary, final, amended or entered in error) | `DocumentReference.docStatus` |
| Kind of document | Kind of the referenced document (e.g. history and physical, discharge summary, progress note) | `DocumentReference.type` |
| Categories of the document | Higher-level category of the referenced document (e.g. physician reports or physician documentation) | `DocumentReference.category` |
| Reference to patient | Patient the referenced document relates to | `DocumentReference.subject` |
| Description of the document | Human-readable description of the referenced document | `DocumentReference.description` |
| Confidentiality of the document | Degree of confidentiality/security of the referenced document (e.g. unrestricted, low, moderate, normal or restricted) | `DocumentReference.securityLabel` |
| Relationship of the document | Relationships of the referenced document to other documents | `DocumentReference.relatesTo` |
| Type of the relationship | Relationship to other documents | `DocumentReference.relatesTo.code` |
| Reference to document | Target of the document relationship | `DocumentReference.relatesTo.target` |
| Content of the document | Document (Base64-encoded data) or reference (URL) with relevant metadata about the attachment | `DocumentReference.content` |
| Language the content was written in | Language used in the document | `DocumentReference.attachment.language` |
| Creation date of the content | Date on which the document was created | `DocumentReference.attachment.creation` |
| Binary data of the content | Document as binary data | `DocumentReference.attachment.data` |
| URL of the content | Reference to the (local) storage location of the document | `DocumentReference.attachment.url` |
| MIME type of the content | MIME type of the document content | `DocumentReference.attachment.contentType` |
| Creation context of the document | Clinical context in which the document was created | `DocumentReference.context` |
| Reference to the encounter | Contact with the healthcare facility, or the type of care, associated with the document content | `DocumentReference.context.encounter` |
| Documented activity | Actions or procedures documented in the context | `DocumentReference.context.event` |
| Clinical specialty of the activity | Clinical specialty in which the document content was created | `DocumentReference.context.practiceSetting` |
| Period of performance of the activity | Period during which the action or procedure described in the document was performed | `DocumentReference.context.period` |
| Type of facility of the activity | Type of facility in which the action or procedure on the patient took place | `DocumentReference.context.facilityType` |

## Search parameters

The following search parameters are relevant for this module, including in combination:

<!-- DERIVED:bridge source=MIIIGModulDokument/TechnischeImplementierung/FHIRProfile/Dokument-DocumentReference.page.md gate=B -->
> **Written during migration — review before release.**
> The machine-readable declaration of the same search parameters is in the
> [module's CapabilityStatement](CapabilityStatement-mii-cps-dokument-capabilitystatement.html);
> the list below adds example invocations and pointers into the FHIR base specification.
{: .ig-highlight .ig-highlight-blue}

<!-- TODO:REVIEW This list and the CapabilityStatement mii-cps-dokument-capabilitystatement
     declare the same 24 search parameters. Should the explanatory list (examples +
     specification pointers) stay here on the profile intro note, or does it belong on
     capability-statements.html so there is only one place to maintain? -->

1. The search parameter "_id" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?_id=12345`

    Usage notes: further information on searching by "_id" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

2. The search parameter "_profile" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?_profile=https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/StructureDefinition/mii-pr-dokument-dokument`

    Usage notes: further information on searching by "_profile" can be found in the [FHIR base specification - section "URI Search"](https://hl7.org/fhir/R4/search.html#uri).

3. The search parameter "identifier" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?identifier=urn:ietf:rfc:3986|urn:uuid:0c287d32-01e3-4d87-9953-9fcc9404eb21`

    Usage notes: further information on searching by "identifier" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

4. The search parameter "status" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?status=current`

    Usage notes: further information on searching by "status" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

5. The search parameter "doc-status" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?doc-status=final`

    Usage notes: further information on searching by "doc-status" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

6. The search parameter "type" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?type=http://dvmd.de/fhir/CodeSystem/kdl|AD010110`

    Usage notes: further information on searching by "type" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

7. The search parameter "category" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?category=http://ihe-d.de/CodeSystems/IHEXDSclassCode|BRI`

    Usage notes: further information on searching by "category" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

8. The search parameter "patient" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?patient=Patient/AmandaAlzheimer`

    Usage notes: further information on searching by "patient" can be found in the [FHIR base specification - section "Reference Search"](https://hl7.org/fhir/R4/search.html#reference).

9. The search parameter "relation" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?relation=http://hl7.org/fhir/document-relationship-type|transforms`

    Usage notes: further information on searching by "relation" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

10. The search parameter "relatesto" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?relatesto=DocumentReference/AmandaAlzheimerOriginalDokument`

    Usage notes: further information on searching by "relatesto" can be found in the [FHIR base specification - section "Reference Search"](https://hl7.org/fhir/R4/search.html#reference).

11. The search parameter "relationship" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?relationship=http://hl7.org/fhir/document-relationship-type|transforms$DocumentReference/AmandaAlzheimerOriginalDokument`

    Usage notes: further information on searching by "relationship" can be found in the [FHIR base specification - section "Composite Search"](https://hl7.org/fhir/R4/search.html#composite).

12. The search parameter "description" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?description:contains=Bericht`

    Usage notes: further information on searching by "description" can be found in the [FHIR base specification - section "String Search"](https://hl7.org/fhir/R4/search.html#string).

13. The search parameter "security-label" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?security-label=http://terminology.hl7.org/CodeSystem/v3-Confidentiality|L`

    Usage notes: further information on searching by "security-label" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

14. The search parameter "contenttype" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?contenttype=urn:ietf:bcp:13|text/plain`

    Usage notes: further information on searching by "contenttype" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

15. The search parameter "language" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?language=urn:ietf:bcp:47|de-AT`

    Usage notes: further information on searching by "language" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

16. The search parameter "location" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?location=below:http://uk-musterstadt.de/document-management-system`

    Usage notes: further information on searching by "location" can be found in the [FHIR base specification - section "URI Search"](https://hl7.org/fhir/R4/search.html#uri).

17. The search parameter "creation" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?creation=eq2025-06-23`

    Usage notes: further information on searching by "creation" can be found in the [FHIR base specification - section "Date Search"](https://hl7.org/fhir/R4/search.html#date).

18. The search parameter "format" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?format=http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode|urn:ihe:iti:xds:2017:mimeTypeSufficient`

    Usage notes: further information on searching by "format" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

19. The search parameter "encounter" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?encounter=Encounter/AmandaAlzheimerEinrichtungskontakt`

    Usage notes: further information on searching by "encounter" can be found in the [FHIR base specification - section "Reference Search"](https://hl7.org/fhir/R4/search.html#reference).

20. The search parameter "event" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?event=http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung|E234`

    Usage notes: further information on searching by "event" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

21. The search parameter "period" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?period=ge2028-01-24&period=le2028-02-06`

    Usage notes: further information on searching by "period" can be found in the [FHIR base specification - section "Date Search"](https://hl7.org/fhir/R4/search.html#date).

22. The search parameter "facility" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?facility=http://ihe-d.de/CodeSystems/PatientBezogenenGesundheitsversorgung|KHS`

    Usage notes: further information on searching by "facility" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

23. The search parameter "setting" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?setting=http://ihe-d.de/CodeSystems/AerztlicheFachrichtungen|INTZ`

    Usage notes: further information on searching by "setting" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

24. The search parameter "nlp-processing-status" MUST be supported:

    Examples:

    `GET [base]/DocumentReference?nlp-processing-status=https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/CodeSystem/mii-cs-dokument-nlp-processing-status|unprocessed`

    Usage notes: further information on searching by "nlp-processing-status" can be found in the [FHIR base specification - section "Token Search"](https://hl7.org/fhir/R4/search.html#token).

## Examples

Extensive examples that illustrate the profile and the extension together can be found on the
extension's page
([MII EX Dokument NLP Processing Status](StructureDefinition-mii-ex-dokument-nlp-processing-status.html)).
<!-- DERIVED:bridge source=MIIIGModulDokument/TechnischeImplementierung/FHIRProfile/Dokument-DocumentReference.page.md gate=B -->
> **Written during migration — review before release.**
> An overview of all example instances of the module is on the
> [Examples](examples.html) page.
{: .ig-highlight .ig-highlight-blue}
