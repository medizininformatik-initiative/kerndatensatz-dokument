# Value Sets - MII IG Dokument v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* **Value Sets**

## Value Sets

This page describes the ValueSets of the **Dokument** module (naming convention `MII_VS_<Module>_<Name>`). For general guidance on using codes, see [FHIR Terminology](http://hl7.org/fhir/R4/terminologies.html); the code systems the sets draw from are described on the [Code Systems](code-systems.md) page.

> **Expansions:** ValueSet expansions in this guide are produced by a FHIR terminology server — SU-TermServ if the client certificate is configured, otherwise the public HL7 server `tx.fhir.org` (in which case some KDS-specific ValueSets may not expand completely).

SNOMED CT content of this module uses the **International Edition, version 20260701** (`http://snomed.info/sct/900000000000207008/version/20260701`) per the MII Terminology Version Policy; the pin is anchored in the expansion manifest (`Parameters/mii-param-dokument-manifest`) and in the ValueSet definitions themselves.

-------

### Defined ValueSets

Overview of the module's own ValueSets, read from the package at build time (descriptions in the resources' source language):

| | | |
| :--- | :--- | :--- |
| ValueSet | Status | Description |
| [MII_VS_Dokument_Einrichtungsart](ValueSet-mii-vs-dokument-einrichtungsart.md) | active | ValueSet zur Art der erzeugenden Einrichtung eines Dokuments |
| [MII_VS_Dokument_Fachgebiet](ValueSet-mii-vs-dokument-fachgebiet.md) | active | ValueSet zum erzeugenden Fachgebiet eines Dokuments |
| [MII_VS_Dokument_Format_Code](ValueSet-mii-vs-dokument-format-code.md) | active | ValueSet zum (komplexen) Format Code eines Dokuments |
| [MII_VS_Dokument_NLP_Processing_Status](ValueSet-mii-vs-dokument-nlp-processing-status.md) | active | ValueSet zum Status der NLP-Verarbeitung des referenzierten Dokuments |
| [MII_VS_Dokument_SCT_Dokument_Kategorie](ValueSet-mii-vs-dokument-sct-dokument-kategorie.md) | active | SNOMED CT ValueSet zur Kategorie (oder Klasse) eines Dokuments |
| [MII_VS_Dokument_SCT_Dokument_Typ](ValueSet-mii-vs-dokument-sct-dokument-typ.md) | active | SNOMED CT ValueSet zum Typ eines Dokuments |

The following ValueSets are defined in this module itself.

#### Document types

To narrow down the possible codes, the following restriction was made with regard to the selection:

* SNOMED CT codes below (descendants of) the code `229059009 | Document type code`

The ValueSet created for this MII KDS module contains exclusively these codes.

See [MII VS Dokument SCT Dokument Typ](ValueSet-mii-vs-dokument-sct-dokument-typ.md).

#### Document classes

To narrow down the possible codes, the following restriction was made with regard to the selection:

* SNOMED CT codes below (descendants of) the code `424545009 | Record composition (record artifact)`

The ValueSet created for this MII KDS module contains exclusively these codes.

See [MII VS Dokument SCT Dokument Kategorie](ValueSet-mii-vs-dokument-sct-dokument-kategorie.md).

#### Format codes

To narrow down the possible codes, the following restriction was made with regard to the selection:

* IHE XDS format codes from `http://ihe.net/fhir/ihe.formatcode.fhir/ValueSet/formatcode`
* IHE-D XDS format codes from `http://ihe-d.de/ValueSets/IHEXDSformatCodeDE`

See [MII VS Dokument Format Code](ValueSet-mii-vs-dokument-format-code.md).

### Logical Definition (CLD)

#### Facility types

To narrow down the possible codes, the following restriction was made with regard to the selection:

* SNOMED CT codes below (descendants of) the code `440654001 | Inpatient environment (environment)`
* SNOMED CT codes below (descendants of) the code `440655000 | Outpatient environment (environment)`
* SNOMED CT codes below (descendants of) the code `43741000 | Site of care (environment)`
* IHE-D XDS healthcare facility type codes from `http://ihe-d.de/ValueSets/IHEXDShealthcareFacilityTypeCode`

The ValueSet created for this MII KDS module contains exclusively these codes.

See [MII VS Dokument Einrichtungsart](ValueSet-mii-vs-dokument-einrichtungsart.md).

#### Clinical specialties

To narrow down the possible codes, the following restriction was made with regard to the selection:

* SNOMED CT codes below (descendants of) the code `394733009 | Medical specialty (qualifier value)`
* IHE-D XDS practice setting codes from `http://ihe-d.de/ValueSets/IHEXDSpracticeSettingCode`

The ValueSet created for this MII KDS module contains exclusively these codes.

See [MII VS Dokument Fachgebiet](ValueSet-mii-vs-dokument-fachgebiet.md).

#### NLP processing status

The ValueSet [MII VS Dokument NLP Processing Status](ValueSet-mii-vs-dokument-nlp-processing-status.md) collects the concepts of the module's own CodeSystem [MII CS Dokument NLP Processing Status](CodeSystem-mii-cs-dokument-nlp-processing-status.md); it is bound by the extension [NLP Processing Status](StructureDefinition-mii-ex-dokument-nlp-processing-status.md).

### Logical Definition (CLD)

-------

### Used ValueSets

#### General information

The following terminologies form the core of the clinical document classification in the DOKUMENT module:

* [Klinische Dokumentenklasse-Liste (KDL)](https://simplifier.net/kdl) - this is the recommendation
* IHE XDS ValueSets (e.g. [TypeCode](https://wiki.hl7.de/index.php?title=Ihevs:DocumentEntry.typeCode), [ClassCode](https://wiki.hl7.de/index.php?title=Ihevs:DocumentEntry.classCode), [HealthcareFacilityTypeCode](https://wiki.hl7.de/index.php?title=Ihevs:DocumentEntry.healthcareFacilityTypeCode), [PracticeSettingCode](https://wiki.hl7.de/index.php?title=Ihevs:DocumentEntry.PracticeSettingCode))
* Optional: SNOMED CT for a more specific classification of the clinical documents or of the associated medical domain

#### HL7 base profile R4

For the ValueSets declared in the FHIR R4 base profile, the following recommendations apply in addition:

| | |
| :--- | :--- |
| [document-reference-status](https://www.hl7.org/fhir/R4/valueset-document-reference-status.html) | HL7 base profile, usually:`current` |
| [composition-status](https://www.hl7.org/fhir/R4/valueset-composition-status.html) | HL7 base profile, usually`final` |
| [document.relationship-type](https://www.hl7.org/fhir/R4/valueset-document-relationship-type.html) | HL7 base profile, usually:`transforms`or`appends` |
| [security-labels](https://www.hl7.org/fhir/R4/valueset-security-labels.html) | We recommend, also for ISiK compatibility, at least the use of the HL7 base profile subset from http://terminology.hl7.org/CodeSystem/v3-Confidentiality, e.g.`N`for restricted / patient-related documents |
| [mimetypes](https://www.hl7.org/fhir/R4/valueset-mimetypes.html) | HL7 base profile, e.g.`text/plain` |
| [languages](https://www.hl7.org/fhir/R4/valueset-languages.html) | HL7 base profile, e.g.`de`or`de-DE` |
| content.format | No separate recommendation, but ISiK possible |
| context.event | No separate recommendation, but ISiK possible |
| context.facilityType | Recommendation per[ISiK](https://simplifier.net/packages/de.basisprofil.r4/1.4.0/files/656621), usually`KHS` |
| context.practiceSetting | No separate recommendation, but ISiK possible |

