# Expansion-Manifest - MII IG Dokument v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Expansion-Manifest**

## Parameters: Expansion-Manifest



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "mii-param-dokument-manifest",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-manifestparameters"]
  },
  "parameter" : [{
    "name" : "system-version",
    "valueCanonical" : "http://snomed.info/sct|http://snomed.info/sct/900000000000207008/version/20260701"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes|3.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/shareablecodesystem|4.0.2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.2"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe-d.de/ValueSets/IHEXDShealthcareFacilityTypeCode|2021-07-06T21:23:52"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe-d.de/ValueSets/IHEXDSpracticeSettingCode|2019-05-17T13:46:31"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe.net/fhir/ihe.formatcode.fhir/ValueSet/formatcode|1.4.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe-d.de/ValueSets/IHEXDSformatCodeDE|2018-12-14T17:07:12"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/CodeSystem/mii-cs-dokument-nlp-processing-status|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-id|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-profile|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-identifier|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-status|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-type|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-category|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-patient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-relation|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-relatesto|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-relationship|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-description|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-security-label|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-contenttype|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-language|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-location|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-format|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-encounter|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-event|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-period|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-facility|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/DocumentReference-setting|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableimplementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableimplementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-implementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/StructureDefinition/mii-pr-dokument-dokument|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Element|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-nlp-processing-status|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DocumentReference|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DomainResource|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/all-languages|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/StructureDefinition/mii-ex-dokument-nlp-processing-status|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://dvmd.de/fhir/ValueSet/kdl|2025"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/c80-doc-typecodes|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-sct-dokument-typ|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe-d.de/ValueSets/IHEXDStypeCode|2020-02-07T07:55:58"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/document-classcodes|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-sct-dokument-kategorie|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe-d.de/ValueSets/IHEXDSclassCode|2021-06-25T13:44:47"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Patient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/Patient|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/PatientPseudonymisiert|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-format-code|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Encounter|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ihe-d.de/ValueSets/IHEXDSeventCodeList|2021-07-06T21:19:41"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-einrichtungsart|2027.0.0-ballot.rc1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-fachgebiet|2027.0.0-ballot.rc1"
  }]
}

```
