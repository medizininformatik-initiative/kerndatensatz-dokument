# Original-Dokument (DOCX) - MII IG Dokument v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Original-Dokument (DOCX)**

## Beispiel DocumentReference: Original-Dokument (DOCX)

-------

**German**

-------

Profile: [MII PR Dokument Dokument](StructureDefinition-mii-pr-dokument-dokument.md)

**MII EX Dokument NLP Processing Status**: Original

**masterIdentifier**: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/6.3.0/NamingSystem-uri.html)/urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46341

**identifier**: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/6.3.0/NamingSystem-uri.html)/urn:uuid:4f8a2e7c-5b3d-4a12-9f87-3c2e9a1d5f04 (use: official, )

**status**: Current

**docStatus**: Final

**type**: Durchgangsarztbericht

**category**: Brief

**subject**: [Alzheimer Amanda (official) Female, DoB Unknown ( Krankenaktennummer (use: usual, ))](Patient-AmandaAlzheimer.md)

**securityLabel**: normal

> **content**

### Attachments

| | | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| - | **ContentType** | **Language** | **Data** | **Size** | **Hash** | **Title** | **Creation** |
| * | application/vnd.openxmlformats-officedocument.wordprocessingml.document | German (Austria) | `UEsDBAoAAAAAAGtjrFwAAAAAAAAAAAAA...`(base64 data - 17,156 base64 chars) | 12865 | `lVW+O8g3uswHHW0s8kirGXp3hJU=` | Amanda_Alzheimer.docx | 2028-02-06 |

**format**: [IHE Format Code set for use with Document Sharing: urn:ihe:iti:xds:2017:mimeTypeSufficient](https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.4.0/CodeSystem-formatcode.html#formatcode-urn.58ihe.58iti.58xds.582017.58mimeTypeSufficient) (mimeType Sufficient)

### Contexts

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| - | **Encounter** | **Event** | **Period** | **FacilityType** | **PracticeSetting** |
| * | [Encounter: identifier = Fallnummer; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt; period = 2028-01-24 00:00:00+0100 --> 2028-02-06 00:00:00+0100](Encounter-AmandaAlzheimerEinrichtungskontakt.md) | Entlassung zur nachstationären Behandlung | 2028-01-24 --> 2028-02-06 | Krankenhaus | Interdisziplinäre Zusammenarbeit |



## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "AmandaAlzheimerOriginalDokument",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/StructureDefinition/mii-pr-dokument-dokument"]
  },
  "extension" : [{
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/StructureDefinition/mii-ex-dokument-nlp-processing-status",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/CodeSystem/mii-cs-dokument-nlp-processing-status",
        "code" : "unprocessed"
      }]
    }
  }],
  "masterIdentifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46341"
  },
  "identifier" : [{
    "use" : "official",
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:4f8a2e7c-5b3d-4a12-9f87-3c2e9a1d5f04"
  }],
  "status" : "current",
  "docStatus" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
      "code" : "AD010110",
      "display" : "Ärztlicher Verlaufsbericht"
    },
    {
      "system" : "http://ihe-d.de/CodeSystems/IHEXDStypeCode",
      "code" : "BERI",
      "display" : "Arztberichte"
    }],
    "text" : "Durchgangsarztbericht"
  },
  "category" : [{
    "coding" : [{
      "system" : "http://ihe-d.de/CodeSystems/IHEXDSclassCode",
      "code" : "BRI",
      "display" : "Brief"
    }],
    "text" : "Brief"
  }],
  "subject" : {
    "reference" : "Patient/AmandaAlzheimer"
  },
  "securityLabel" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "N",
      "display" : "normal"
    }]
  }],
  "content" : [{
    "attachment" : {
      "contentType" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "language" : "de-AT",
      "data" : "UEsDBAoAAAAAAGtjrFwAAAAAAAAAAAAAAAAFAAAAd29yZC9QSwMECgAAAAAAa2OsXAAAAAAAAAAAAAAAAAsAAAB3b3JkL19yZWxzL1BLAwQKAAAACABrY6xcxppPZfoAAAAhBAAAHAAAAHdvcmQvX3JlbHMvZG9jdW1lbnQueG1sLnJlbHOtk91OAyEQhV+FcO+yrVqNKe2NMemtWR+AsrM/cRkITI19ezF2KzUN8YLLOTOc+TI5rLefZmIf4MNoUfJFVXMGqG07Yi/5W/Ny88i3m/UrTIriRBhGF1h8gkHygcg9CRH0AEaFyjrA2OmsN4pi6XvhlH5XPYhlXa+ETz34pSfbtZL7XbvgrDk6+I+37bpRw7PVBwNIV1aIQMcJQnRUvgeS/Keuog8X19cvS67Hg9mDj3f8JThLOYjbkhCdtYSW0jOcpRzEXUkIwPYPw6zkEO6LZgGI4t3TNJyUHMKqJIK25ruVIMxKDuGhbBqQGrWfIE3DSZohxMVf33wBUEsDBAoAAAAIAGtjrFxnKzn/chIAAAZvAAARAAAAd29yZC9kb2N1bWVudC54bWztXUtz20iSPs+/yFBEb8jTfADUwxR73BPUWyvLrTBp9UTfikARKLNQhakqiBZPe5h/MBFzmoi++AfMySedhvf9EftLNrMAPmS525J71y1aVoQoEiASlV/lu7KgP/35TSbhkhsrtHq2FjaCNeAq0rFQybO1V/3DensNrGMqZlIr/mztitu1P3//p3En1lGRceUgizonidKGDSSeH4ebMA63YJyHm2uAxJXtjPPo2VrqXN5pNm2U8ozZRiYio60eukaks6YeDkXEm2Nt4mYrCAP/Ljc64tbiSPaYumR2Ri67TU3nXOHJoTYZc/jRJM2MmVGR15F6zpwYCCncFdIOtmdk9LO1wqhORaI+HxBd0ikHVP2ZXWHuct/ykv0KHX/HpuESx6CVTUW+YONTqeHJdEbk8teYuMzkYgrCzd82B/uGjfHPguBdhh+XF2WyHPmvUwyDO8wIkZhfcZch3LznbCQZE2px40+CZgnccOt+BFrvE8iT3zY5R0YX+YKa+G3UTtRoTot0/h60qkleZs3+tsH0UpbPNTB6czdildwRvc1mlDLj+JsFjfDeRLaaO832bUKtTyCEDLbC26Q27k1qu0mjukXojrL8HiEc1S1KdxTq9yl9gLntT6PUuk3p6adR2rhNqf1plG6JExqS0SeQEgsdY9lGfG8KT5uZjrncWBjDcDvid1SPma61K2VtRgt+iI6443hmdLbndMTyeD5tMEsEbOzi9F5UWjPb3KRrmWMps+kyxfuZM9TXGbmrDDGiwGeg4yv6m/uXc0N/bM4inBgYd9jQcYwTtoO1Jp14HeGxSyafrUXov7mho835ZeVL9f5QK2eJgo0EGvCuEQyxGHciu/SBM+u6VrClQ2lX2fn3/U0H5eue9X/tZDaEje216sievXmsOR+GI6w8P4hUbrjl5pKvfT/9m5k4KRAyAwfKSWbtwAg+pCtdeX3J2EeRaW3+ntCI8vUWNK3WbWjKYx+FZr8wUZowlViGGA24QZTc/XEpJeazysZHWTvHqBXnRqgO3GDo/2l0Hx1PN6NEBLpyknKRcfPJ0vewYO4WQ0Q5ZdI9EJxbm40gbKA1bcP//NffIdhuBK3y47pAVUVqlxmPxUQoQVYUdnmKEyMLlTy5/5S0P8eMfJTlHk8NJBxfcVBwzI2BUy0lT3gN7NI5ODSsqE4JVVtVdsfCQGWquIKTVOErG+BkSsGnP3MVw/Qaz0Oh8AKOzGdcKMsyDnObAO9rYw1iwcEiTbjUGSwJ0UBYmBTZsiDh9SVtAx8SKbUkUzjQIb5tfBTrvOeuJJ+Z72POqIoRVob9/XkIWwEhh7S14b+PYbjhgNofcEDtuzkgwRKlLVf3BOi5sO6cGZYYlqfl3VWRld8U8lLOvhfMz53E86FVI6su+L3F+SW3eQNOlC0wfJugfE5QaAScS14Yxk0yvbaIDwxie18p+oJAOtXZoAFdjVZMjSTLc64uhROol5lw1XGLvyhKcDr9xyEEtaePHa0z4QyTSzDhr+Oy7k1aqjHwM2hlErRivQq59RK6RrseNjY+7g6/WPwU1eCQs+cX9UPYakCEtn5g6MgJGvjp2wx9hcjQzBtOHiP2ELIso0ganZACKTzgsRgOC1Le6VuJhhvfiOr60k9ccDN9q/By9BSP2QReNFgDzhUvMq0Q2nCrEXpX+4hV+KeGQnuX61zyN9AKghasH/NM5Iy+AYY/gRFGNRzQe4i4eMzCc3yVa5deGU4WjDxnt3BaZFmhyqMiRgtoHy8+GGINuOMWMi6lcIWtTBNDF/GC56nROXOp4I8XoSPDMsUTTA4uOfR4btE/rh/qEUKVFxJtEpOgycgfM6PGmFY9YtfYHRUkSy8EuTNae2X391yPJrvppxxn/A6q9UAz7daGT4PbHTgtY26abzeBs9MDDCJ1Dbr4prWBmuE/nUqeZROO1qWVbgRoZlQNemfQi9Ixmh6O4Y5yRoy4hLC2UYMLbVI9hHCjAdtwcFqDdoAXSTh+flbflYWrQQv6px9Peh4qeFsz8PoHBzUoFMMEDwNBKRJoPZ2dOz7p1xEghQChXrnqaw0ETitdJYEri0B7iUuoLCxshLOjXZUIXd/b60NrZ3Zsl0pTCvYuLo5Xle1gy1eKkBlirVAxHJ3W8V1XkZuxvAPTfw64USzNOFxq5fOHDehNr2OMgn2aBpTBCYyFMa/NqvS2SuSI3nB6naL5jRepWwP+k7uJA0val3K00Xg7KoVNCsXxPvgOw8WEOzO9HjhPZP/K5mr6bmX1q2S4qtS1feT3w3n9RMVi5BtWPJOKYX6GZsfidZRyEWRodwaUuTnMujp4DR2g+l152Vdf9gs5GjcSTdOqSgvKSZVTwkGU6hEzsdA+HhO8s6pMhRjB+1IFJEZPf6Yy9kirCblZX8pOr3K0IBjgp96SGJBCjUgD5o6YbI3S+NWkoPNU8CjU6E568EAxaTWWjaetqmA3a4brZydwcvLvf9XgrOffPCHgli76QKGxBq4wg0L69V44lMX052qdgVYOqguYxAtqvtAmG3BE9TVqM2xhXJMdJ7BORooWKjitXaDx3gWWAU85lS7RXuExXx9Cw/YE+jjGf/9rVacBg7oDk07fIZ+wb4poNCZkqWo2klS4UHCKJtiSSUGnV8mcHU+vDZUkl6vfKNd3K34/UCSWLM8psigk/NCFc6OR712D+pgxpTpej7XTVNF5Wf+RsMIQUKjCmvTKpVlhv4N6/T8S9x3MkoqJQP2N0dX71gaUc/zyQEimJlWh15IxoEH4xNbAGZv+7IMOBfVZnEX630fXlKGhGBZWm1IK8TQ6TnKQeAdLU4U0lFDjUj3qkE3fJXRfjFjLOlQ5YbFhQlFGyJRkfvlRk8tVcCAUmql81W3LYipfVio8F9TC4hAKE/MKQVRpI6RfDKQAwVd4AUHWMimrxqXQI6A+UAlrLXguPMUDYIOEU5sKVw04FlQephPMZdx5a7NYx5zNfxnjoCS52VomTqjIU1oA7aFBcYJGAMJnGERsO/gGfmjBax9EkVztBN80SlGon89kQU7fFkMHqKPQaoQ1SOdjGQhL7TQjhRYSngYBpm2ssAlH8yV4jONe1Sl+0cGJyYWUvlivRxrhJIAdqkAiBlyuKmPnHW9FYcAsxgskYThX4+lbEmN0eEfIJYmBQaUtNXrIi3KF/eWRhb0ObDW3oXdlnZZiVGSrCkO3A2NSvxrsH2HyZWih/g4FrAfKzUEHEtRztC3wqgfTf8Q8887yaxLzC0pArdnokD5nsXvjYRVwUfpxUlP0Hbs+WKjBTxRI1LeCAP16PQzImD9eeMjXveSOvCsGTzkyhU6XnK+3hY8XF8pcMJDjPk289HlKlcVQXFGdqaKhO4d5XyxaS9H1hZayfsxRkqg9zAdQSaVz5/0+bAX1p4Hl0Xer6oKICcxrnKG2QliKkMOnnWCbQtUGZgGZ0pQ511BSxjwaDRiGVUy5MaXNZcXzNSsLdhh7+IAzoaRYlk2LyQoHlF0ftROHP+ROHEo9XgqjyyB9ZXmzedCaJQ+we9Qty603jQDO6uWszeUTWssfBqPE59ZWDfI9fLO57YvNthi85iNa0ZjX2HFGu46jrDuUcyp+lAm0gaBVP2ID7gW7HXyzqjCcknIeCj6gJDPxiwyY9kYpF7G3al7Z5yUFn0c25us+ZW1CrLAUvJcbRpghY6x9Mz2kTOm4D2XVhtq8YAPzJot5E5ycwMneSzB8ZfW9zCFR+uX0GsdF5hyF/k0uDHPa+KY2C6fo5hzVfJDRMtvEXGv6NsuHpA1SVAdXFYNFAklpMuz3kLtvv11VbjCBzDAu8d2OVfr4qipDc0ULBDTf86yp4438wtuTGbx4PxYke2d8T3NPuKJciqvPS7x+CYIqiEmCtmHvvHu+qtAFG/MNAdO/VU2cnvnu7puVXVH6I1Xo+z2/CSII5wyeSj7A2JUsX1ldJEd2LjB8QS4kTinNOKm9cmCFimugyCjCax7T4hJ9u88mesCilbV9f4R9BidqiC5/kRUixwKDU+T3VWa5m/Aydj3jRiueQetNCEmT8Fo/Rguoh0I64zXiycriEGzOpWKpRQWa0B3EGoOgDpxRvA4YtTvfaX6pyyWy5xQ2lBEiFRljRgXkfgMizaVgUWErmRkgPYRVYo6wsiCdF9KWls/X6FXJ/CVXXn88577n2a8iUCV9Ipb2f6ws255LalFWUXqVATKnmclWlp0T9HM4V/QMFr9VcC/FJNY6ZlF8j3YxQx1Or6V08C30ZBEn88r5j0zFmPPEIhqhT1hZ9s+HmJ0z9GhDWuzuQNiGKGvaGnQbJSgRg5cnfrGyA0GtvU3yHBeTag3dL5FbkVD3LGrBxd7JyiLhu13RapUhH3UBoxQUtbILtoxovj0TclJZMNpuyNNVtl8vOXWNcCNoRbrIbvFFi5TIOQpA2bNZm7kBKarvxsxQ/WalrfjC1a0qB8f9o6pJBSes7ZdphaInDK1yGl71V1IEcqPBkppHMceMOdAiOzpdH2tgfpJIv+Duq7GvYH3fWMxNMMLwe4RjMtcYuRnaH0Gu2ndOUWbzlzf486RRVjXG07e+5RL6himb62rZvkyWishXesqmsvmWAbQRAyEbsDTeo9O9fr0cJY2jgSP2eRMfP+nAqXce/dTobEBbYmfuZL7nDI9cUt14aDjGU4eHFKtXUVft5n40zNmupDYYU9GdcqPf+BQP09VCI4+o0dN3mOwxN31n3/dXULaZjKbvqJvAx7Nk9V5JCtFS6gERvjHh5gbVDtmD9QhjmtIiPPF1QZ/ur8+bFMZc0X7DJ9AvBgUVTjjGiE7wYSWke1Qkp8fEUOZZDYMpBS10PDApzPQ6GiV8omlyxzjgFS4LLwkFtYD3qfe7qpR9ASztzcV8ZTPhC9Q0lH5agci1dcsbN+H59C09c3ChosOy+HVDVcsztJHB9/6srqQuHnzgHxdjS/9OTSNke1BhJXW3x3QODtGmkV07o8gYNXq9u3eMpq2Km8pnItgBx+hguLKAHGT5kKfSzypmu2Jk9EBoqROBVnBf8JuHYkY9NFy5co0AeviFAfXnIYRovlXKVjhFeM4G2nT8a/0lt4V0yC2s/8Sp6Ra9zGsOG9Bn998x92g6UrojV/jNUWe/cQdC6xegat9AKvwscvMrSG1+AKnNOyFVAkSPEkUJk9S3yMEvqqFpaW1Cz1Hopz7n1szZuB9I08G+wEQ9YgqgDpsY6yewqyWGWYSPD/2HGPSLBBIuMez7ePj/BQOV0DN/ohEhFdRac6TqELY6wQ48Z280xqMYw/dNPmzQ11pB4hzkDd0gPMNbaPpTjxfS5/V+ekVphpe+cCv47+tkgRYJ34/Uz2weOUyzhQHCaEk9Q6+eL9ieRHHc+Xh7wBeLzzmm4nqiZWnCUC9PT77ic6MuhyY+Lk18iPDga9jZCKC3v1/vFTanZ5Fpf3YLAZvp39b/ibV6LHHGiRoWZXY3DzMW4UUNdIpZXS/H/MYnAI843vDLI0NqaEN526mhijZTWN/yuvqIYZmbqa+w/CIsYTjDpbVFuNQAfON5AhdMRTq7QtvymMHqG50P6wtL1IFu5GjXXwzHZ2XUGrZaB81Rghh68BZydgDe5t/wmI8Zy67xj14rgwqPG8amhFyGMCF223PoUPy+Qnfz0VqxoTZHJ2wZVaCY7bSzZC53rbkae+X9it6NblkmRZFFqdQG9fZpbXOrtH1BdvDX1NxU2+0gQxY8gNu3U/XHjGKvyA11lIiZALbDm/q7+UH9/QrgDMAfhQFMGUYYzw6n12UvVm50lmNg+96DaPzzoefPRPZrh9bxdHblS1p/G/rtGLTtUM22OlPTo24kDehzifG/qr8wDVquo7VXvJB2Hjd8YbyLEXM6fWeoZ+5DN0zZgFb2cMCLJyvQc0e437w8KaqHPfu7ls9/dg1Yr+7agR7G5khNC7tEM2jv7ITN1sbG1qZfgbiCYHtnpx5uBTs77fbTRywYZ8LRUjLOsn+CgIJR+WRwv1B8ZPyTFz7nHq4HBk/5iAZazHrhHxjkYBfBQonyP6eSFRbOh1wMh7NjSz/nRlw26vt6UlLIeNyAvzB6CkPZePB4YV3+bxz7wvCR08vw/UB1V/wG/OEP82P4tmvL9uIJnfsgeJZHroIu6VEdYPxsLQx36H+m4Sjx/XZ7o03v0Rtz5XBIGNcYJlwJWZ6cMYNnnc7xu5ubvpqBhip1i48D7ZzOFp/R7CydTTn1yj1bexr42wy1dksfk8L5j8Hsdi+KrH+Vc/8p1tERxQhIUih+LlyU0n83mZVQZqw1Z//Apbn4F3bf/y9QSwMECgAAAAgAa2OsXOVi43dWAwAAGBQAAA8AAAB3b3JkL3N0eWxlcy54bWzlWG1P2zAQ/itRvo80aVpKRUFdoQIJbYiB9tl1nMYisTPbobBfPztx0jQvtNBQpu1T67vL43ueO9eXnp4/R6HxhBjHlExM+6hnGohA6mGynJgP9/MvI9PgAhAPhJSgifmCuHl+droac/ESIm5EcHy9JJSBRSi9K9s1VvbANCQq4eMITsxAiHhsWRwGKAL8iMaISKdPWQSEXLKlFQH2mMRfII1iIPACh1i8WE6vN8xh2C4o1PcxRBcUJhEiIn3eYiiUiJTwAMc8R1vtgraizIsZhYhzqUQUZngRwKSAsd0aUIQho5z64kiS0RmlUPJxu5d+i8I1wOBtAE4OoOT3KLxAPkhCwdWS3TK91Kv0Y06J4MZqDDjEeGJOGQZy+9UY8tICAS6mHIOSKZgSXsRbabV/S/MTCCem4+SWGd+0WXpjq5pOXKyyqEruaSdJKPESyxaKAQNLBuJAJZK6rr2JeY9FiFLiBEQo3zezpuksAEfed5J7vqla6twJehZN9l/ztOBWSbE1zcGwTjOzlWim6e1K4QoBdarsGgvtMOwumUAaUlbU5/LY/TqoVrLfUMl+tZLvoei0UnQOTNFpqKLTRRX7rRT7H0bRnrsXx6MaRbeBotsBRbeVotslRZwu8Ixbr9R0TyqDViqDAzTknskPW5MfHqDV3pv8D8EoWdZS1+YO815kWGn/vDfZG8zFbeGp5qy8xtq9Lfd1ju1pwEDCQYHYZsGlj4WYPNYrXniadteXaZGiuvazwATfMkyZHKjy2JMT7SEB9tDPAJEHidXaCL3BsD/TF1OSG9VIlN272wVvZjqnVBAq0B3yEZPzZv1q93WEwYqQrqhzFOEr7HmIbFFCjsViGuJlsRtPZBk4ZDgW+5yNnP297PJ24kJ5tzWb6oncXoadSdn31yHWU1EMoPq9kYOkLyspu0LRkVsjddUUi7tEvQKARFAtjn68Nls5vYYrq9dFPxXUq6rmAYaKMNbq7NxObUJ31mwfKc8l8V4/bSgL+BcPm+beeNZy2m8+aiXQ/+ykVZlXJdX+Ts5ZuXR/1zH71De8tl6xnbRBFsinTPdLGk8ToZrm5iksbvXGtunw74LyULah+ahB873mzAO9crZpPtqQ3B61Sm5/muRveD/Mv/GzP1BLAwQKAAAAAABrY6xcAAAAAAAAAAAAAAAACQAAAGRvY1Byb3BzL1BLAwQKAAAACABrY6xcGA1GXLABAAAwAwAAEQAAAGRvY1Byb3BzL2NvcmUueG1spZJBbtswEEWvQmgvUZLbtBBkBm5TA0ZroEAdtMiOJcf2wCIlkGM79qqL3qBHyk16kpKyrSRIdt2JmDePXzOsr+9Nw3bgPLZ2nBRZnjCwqtVoV+PkdjFN3yfMk7RaNq2FcXIAn1yLWnWVah18dW0HjhA8Cx7rK9WNkzVRV3Hu1RqM9FkgbCguW2ckhaNb8U6qjVwBL/P8ihsgqSVJHoVpNxiTs1KrQdltXdMLtOLQgAFLnhdZwR9ZAmf8qw195QlpkA4dvIpeigN973EA9/t9th/1aMhf8B/zL9/6X03RxkkpSEStVUVIDYiH3+5IDQbAsU+WGun9T4ewZH9//WETEwfLJs1xDWjA1XzoiwblQFLrxBw0HtGiPc0QN+nMImH42kHfcgFjkwavHHYU9immuImMY5MQ4nTtcWvYfDZjn8GFqwmsl3Q0rd427KbdbONIe+VTTdx2CE7z8CyWCPrDQdza1EoDuuYvaxF3sMP4pETRE8OxPm/oFBk0C5OtTnu4VL6PPt4spoko8/Iqzd+mRbkoyqp8V5Wj7E2R38V4zxyPUnMO8V/Wi0T0yZ+/cvEPUEsDBAoAAAAIAGtjrFzio178tgIAANgSAAASAAAAd29yZC9udW1iZXJpbmcueG1s7VhLbtswFLyKQKDLmJIsO4YQJWgbpHDRH9D0ALRE24T5A0VJ8a77Lrprt0WP1pOUlC3509ix5RrQIitGfO/NDIfkI5yrmwdGnRyrlAgeAa/jAgfzWCSETyLw5f7uYgCcVCOeICo4jsAcp+Dm+qoIecZGWJk0h8XhcMKFQiNqEgovcAqv5xTSC4Bj0HkaFjKOwFRrGUKYxlPMUNphJFYiFWPdiQWDYjwmMYaFUAn0Xc8t/5JKxDhNDcdrxHOUVnDsXzQhMTfBsVAMafOpJpAhNcvkhUGXSJMRoUTPDbbbr2BEBDLFwyXERS3IloQLQcuhqlCH8C5KbkWcMcx1yQgVpkaD4OmUyNUymqKZ4LQCyfctImd0tQVecNoe3CpUmGEFeIj8ZFHE6EL5fkTPPWBHLERdcYiETc5KCUOEr4gbWbNmrtc7DsDfBpCT0zbnjRKZXKGR09CGfFZj2Ut/BNZyk9eXlp4m5vMUSQxsy0GjVCsU6w8Zcza+holpXcC2nVBh062UnVx0p5djjdUrhdEsAm6JwjKqyTucY3o/l9gA5YgahfORIsl7G6M2BqDNpTk1CcQMtrok0OYamrucY0tpc0q+CsZb1JnmeMfqyVFGKdY14j1+qEN/fn6v59/G1SzF42W6/KTsQHhiYnY6Ape+VRJOEZ+UTbrbd20uXCbDEmtbvHce8d+OFe8FQQP1/lnU//h1rHrf6zdQ323JwfEHgwbqg5acHCO2gfpeS05O0G1ya/stOTk9t8mtvWyL+ssmt3bQEvX94LBbCzdexCefS7+9z2WCY8IQfdTAF17nTO/lkf512+vfvvP39Xc77Aue7TvFvt6zfU/Yx0vbePXbYMvRYbK1BoPyMcfKuILXPKhXvBZbVcGNsvKbP0Lu7yb3z07e3U3ePTt5sJs8+P/kcO1/Utd/AVBLAwQKAAAAAABrY6xcAAAAAAAAAAAAAAAABgAAAF9yZWxzL1BLAwQKAAAACABrY6xcH6OSluYAAADOAgAACwAAAF9yZWxzLy5yZWxzrZLPSgMxEIdfJcy9O9tWRKRpL1LoTaQ+QEhmd4PNHyZTrW9vKIpW6tpDj5n85ss3QxarQ9ipV+LiU9QwbVpQFG1yPvYanrfryR2slosn2hmpiTL4XFRtiUXDIJLvEYsdKJjSpEyx3nSJg5F65B6zsS+mJ5y17S3yTwacMtXGaeCNm4Lavme6hJ26zlt6SHYfKMqZJ34lKtlwT6LhLbFD91luKhbwvM3scpu/J8VAYpwRgzYxTTLXbhZP5VuoujzWcjkmxoTm11wPHYSiIzeuZHIeM7q5ppHdF0nhnxUdM19KePIxlx9QSwMECgAAAAgAa2OsXKCOjqWaAQAAOAgAABMAAABbQ29udGVudF9UeXBlc10ueG1stVbLTsMwEPyVKFfUuHBACLXlwOMIHOADXHuTGmKvZW8K/D3r9CEFmlKguWU9MzsT70bK5Ord1tkSQjTopvlpMc4zcAq1cdU0f366G13kV7PJ04eHmDHVxWm+IPKXQkS1ACtjgR4cIyUGK4nLUAkv1ausQJyNx+dCoSNwNKLUI59NbqCUTU3Z9eo8tZ7mxia+d1We3b7z8SpOqsVexYuHrqQ9+LXmJ8nc+o4i1fsVlSk7ilTvV8RldcL32FHxWa9Kel8bJYmJYun0lzmM1jMoAtQtJy6Mj98MGI0HOXwVpvqPybAsjQKNqrEsKXBeNpHZoO+4SccENVF7bQ+8ocFo+I/PGwbtAyqIkZfb1sUWsdK41c08ykD30nJvkehiS1m/7iA5In3UEHcHWGH/st8sgsIAIzb2EMjs8OOAj4xGkYjHfGHVREJ7mHVLPaY5pG3SoA+y59aDTto1dg6Bn3cPewsPGqJEJIfUt3FbeNAQPJM9GTbosJ8dEPFT34e3RgeNoNAmoCfCBh14G7iRnNfQtw1reBNCtL8Cs09QSwMECgAAAAgAa2OsXFh52yKSAAAA5AAAABMAAABkb2NQcm9wcy9jdXN0b20ueG1snc5BCsIwEIXhq5TZ21QXIqVpN+LaRXUf0mkbaGZCJi329kYED+Dy8cPHa7qXX4oNozgmDceyggLJ8uBo0vDob4cLFJIMDWZhQg07CnRtc48cMCaHUmSARMOcUqiVEjujN1LmTLmMHL1JecZJ8Tg6i1e2q0dK6lRVZ2VXSewP4cfB16u39C85sP28k2e/h+yp9g1QSwMECgAAAAgAa2OsXOL8ndqTAAAA5gAAABAAAABkb2NQcm9wcy9hcHAueG1snc5BCsIwEIXhq4TsbaoLkdK0G3HtoroPybQNNDMhE0t7eyOCB3D5+OHjtf0WFrFCYk+o5bGqpQC05DxOWj6G2+EiBWeDziyEoOUOLPuuvSeKkLIHFgVA1nLOOTZKsZ0hGK5KxlJGSsHkMtOkaBy9hSvZVwDM6lTXZwVbBnTgDvEHyq/YrPlf1JH9/OPnsMfiqe4NUEsDBAoAAAAIAGtjrFycicmRzgEAAK0GAAASAAAAd29yZC9mb290bm90ZXMueG1s1ZTNTuMwEMdfJfK9dVIBWkVNOYBA3BDdfQDjOI2F7bFsJ6Fvv5PETbosqgo9cYm/Zn7zn5nY69t3rZJWOC/BFCRbpiQRhkMpza4gf34/LH6RxAdmSqbAiILshSe3m3WXVwDBQBA+QYLxeWd5QeoQbE6p57XQzC+15A48VGHJQVOoKskF7cCVdJVm6TCzDrjwHsPdMdMyTyJO/08DKwweVuA0C7h0O6qZe2vsAumWBfkqlQx7ZKc3BwwUpHEmj4jFJKh3yUdBcTh4uHPiji73wBstTBgiUicUagDja2nnNL5Lw8P6AGlPJdFqRaYWZFeX9eDesQ6HGXiO/HJ00mpUfpqYpWd0pEdMHudI+DfmQYlm0syBv1Wao+Jm118DrD4C7O6y5jw6aOxMk5fRnszbxOov9hdYscnHqfnLxGxrZvEGap4/7Qw49qpQEbYswaon/W9Njp+cpMvD3qKFF5Y5FsAR3JJlQRbZYGiHz7PrB28ZxwhowKog8HanvbGSfc6rq2nx0vQhWROA0M2aTu7jJ863Ya/66C1TBXmIal5EJRy+mSI6RuNqPo77E26SPR3QQTOdvT5Nl4MJ0jTDK7P9mHr6EzL/NINTVTha+M1fUEsDBAoAAAAIAGtjrFzSd/y3bQAAAHsAAAAdAAAAd29yZC9fcmVscy9mb290bm90ZXMueG1sLnJlbHNNjEEOAiEMRa9CuneKLowxw8xuDmD0AA1WIA6FUGI8vixd/rz3/rx+824+3DQVcXCcLBgWX55JgoPHfTtcYF3mG+/Uh6ExVTUjEXUQe69XRPWRM+lUKssgr9Iy9TFbwEr+TYHxZO0Z2/8H4PIDUEsDBAoAAAAIAGtjrFw/So6NwQEAAJIGAAARAAAAd29yZC9lbmRub3Rlcy54bWzNlNtu4yAQhl/F4j7BjrrVyorTix5Wvaua3QegGMeowCDA9ubtd3wIzrZVlDY3vTGnmW/+mTGsb/5qlbTCeQmmINkyJYkwHEppdgX58/th8ZPcbNZdLkxpIAifoL3xeWd5QeoQbE6p57XQzC+15A48VGHJQVOoKskF7cCVdJVm6TCzDrjwHuG3zLTMkwmn39PACoOHFTjNAi7djmrmXhu7QLplQb5IJcMe2en1AQMFaZzJJ8QiCupd8lHQNBw83DlxR5c74I0WJgwRqRMKNYDxtbRzGl+l4WF9gLSnkmi1IrEF2dVlPbhzrMNhBp4jvxydtBqVnyZm6Rkd6RHR4xwJ/8c8KNFMmjnwl0pzVNzsx+cAq7cAu7usOb8cNHamyctoj+Y1soz4FGtq8nFq/jIx25pZvIGa5487A469KFSELUuw6kn/W5OjFyfp8rC3aOCFZY4FcAS3ZFmQRTbY2eHz5PrBW8YxABqwKgi83GlvrGSf8uoqLp6bPiJrAhC6WdPoPn6m+TbsVR+9Zaog96OYZ1EJh++jmPwmWxFPp+0Ii6LjAR0U0+j0UaocTJCmGR6Y7du00++f9Yf6T1RgnvvNP1BLAwQKAAAACABrY6xc0nf8t20AAAB7AAAAHAAAAHdvcmQvX3JlbHMvZW5kbm90ZXMueG1sLnJlbHNNjEEOAiEMRa9CuneKLowxw8xuDmD0AA1WIA6FUGI8vixd/rz3/rx+824+3DQVcXCcLBgWX55JgoPHfTtcYF3mG+/Uh6ExVTUjEXUQe69XRPWRM+lUKssgr9Iy9TFbwEr+TYHxZO0Z2/8H4PIDUEsDBAoAAAAIAGtjrFxNn8rKoQEAAHMFAAARAAAAd29yZC9zZXR0aW5ncy54bWyllN1u2zAMhV/F0H0iu1iLwahbdCvW9WLYRbcHYCXZFiJRgiTby9uPjuO4P0CRNFeSQfE7R6TF69t/1mS9ClE7rFixzlmmUDipsanY3z8/Vl9ZFhOgBONQVWyrIru9uR7KqFKiQzEjAMZy8KJibUq+5DyKVlmIa6tFcNHVaS2c5a6utVB8cEHyi7zIdzsfnFAxEug7YA+R7XH2Pc15hRSsXbCQ6DM03ELYdH5FdA9JP2uj05bY+dWMcRXrApZ7xOpgaEwpJ0P7Zc4Ix+hOKfdOdFZh2inyoAx5cBhb7ZdrfJZGwXaG9B9doreGHVpQfDmvB/cBBloW4DH25ZRkzeT8Y2KRH9GREXHIOMbCa83ZiQWNi/CnSvOiuMXlaYCLtwDfnNech+A6v9D0ebRH3BxY47s+gbVv8surxfPMPLXg6QVaUT426AI8G3JELcuo6tn4W7Nx4kgdvYHtNxCbhmqBcpfGx5DqFd6h/C3lTwWSplk2lD2YitVgomK7M9OUWHZP0wCbTxaXjLYIlqRfDZRfTqox1IUTSj5K8kWTL/Py5j9QSwMECgAAAAgAa2OsXIuGOcTFAQAAxggAABEAAAB3b3JkL2NvbW1lbnRzLnhtbKXU3XLiIBgG4FtxOFeSWFM307Qnne30eNsLoIDCNPwMoNG7X1IlSZedToJH6iTfk5fXwMPTSTSLIzWWK1mDfJWBBZVYES73NXh/+73cgoV1SBLUKElrcKYWPD0+tBVWQlDp7MID0lb4VAPmnK4gtJhRgexKcGyUVTu38vdCtdtxTCExqPU2LLL8DmKGjKMn0Bv5bGQDf8FtDBUJUJ7BIo+p9WyqhF2qCLpLgnyqSNqkSf9ZXJkmFbF0nyatY2mbJkWvk8ARpDSV/uJOGYGc/2n2UCDzedBLD2vk+AdvuDt7MysDg7j8TEjkp3pBrMls4R4KRWizJkFRNTgYWV3nl/18F726zF8/woSZsv7LyLPCh247f60cGtr4LpS0jGvb15mq+YssIMefFnEUTbiv1fnE7dIqQ7q+sq9v2ihMrfUdPl+qHMAp8a/9i+aS/Gcxzyb8Ix3RT0yJ8P2ZIYnwb+Hw4KRqRuXmEw+QABQRUGI68cAPxvZqQDzs0M7hE7dGcMre4WTkpIUZAZY4wmYpRegVdrPIIYYsG4t0XqhNz53FqCO9v20jvBh10IPGb9Neh2OtlfMWmJX/tq7tbWH+MKQpgI9/AVBLAwQKAAAACABrY6xc0nf8t20AAAB7AAAAHAAAAHdvcmQvX3JlbHMvY29tbWVudHMueG1sLnJlbHNNjEEOAiEMRa9CuneKLowxw8xuDmD0AA1WIA6FUGI8vixd/rz3/rx+824+3DQVcXCcLBgWX55JgoPHfTtcYF3mG+/Uh6ExVTUjEXUQe69XRPWRM+lUKssgr9Iy9TFbwEr+TYHxZO0Z2/8H4PIDUEsDBAoAAAAIAGtjrFxj7V7WHQEAAEMDAAASAAAAd29yZC9mb250VGFibGUueG1sndHdbsIgFAfwVyHcK7WZjWms3ixLdr89AAK1RA6n4eDUtx+ttmvijd0VEPL/5Xxs91dw7McEsugrvlpmnBmvUFt/rPj318diwxlF6bV06E3Fb4b4fre9lDX6SCylPZWgKt7E2JZCkGoMSFpia3z6rDGAjOkZjgJkOJ3bhUJoZbQH62y8iTzLCv5gwisK1rVV5h3VGYyPfV4E45KInhrb0qBdXtEuGHQbUBmi1DG4uwfS+pFZvT1BYFVAwjouUzOPinoqxVdZfwP3B6znAfkTUChznWdsHoZIyalj9TynGB2rJ87/ipkApKNuZin5MFfRZWWUjaRmKpp5Ra1H7gbdjECVn0ePQR5cktLWWVoc62F2n1x3sPsy2NACF7tfUEsDBAoAAAAIAGtjrFzSd/y3bQAAAHsAAAAdAAAAd29yZC9fcmVscy9mb250VGFibGUueG1sLnJlbHNNjEEOAiEMRa9CuneKLowxw8xuDmD0AA1WIA6FUGI8vixd/rz3/rx+824+3DQVcXCcLBgWX55JgoPHfTtcYF3mG+/Uh6ExVTUjEXUQe69XRPWRM+lUKssgr9Iy9TFbwEr+TYHxZO0Z2/8H4PIDUEsBAhQACgAAAAAAa2OsXAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAQAAAAAAAAAHdvcmQvUEsBAhQACgAAAAAAa2OsXAAAAAAAAAAAAAAAAAsAAAAAAAAAAAAQAAAAIwAAAHdvcmQvX3JlbHMvUEsBAhQACgAAAAgAa2OsXMaaT2X6AAAAIQQAABwAAAAAAAAAAAAAAAAATAAAAHdvcmQvX3JlbHMvZG9jdW1lbnQueG1sLnJlbHNQSwECFAAKAAAACABrY6xcZys5/3ISAAAGbwAAEQAAAAAAAAAAAAAAAACAAQAAd29yZC9kb2N1bWVudC54bWxQSwECFAAKAAAACABrY6xc5WLjd1YDAAAYFAAADwAAAAAAAAAAAAAAAAAhFAAAd29yZC9zdHlsZXMueG1sUEsBAhQACgAAAAAAa2OsXAAAAAAAAAAAAAAAAAkAAAAAAAAAAAAQAAAApBcAAGRvY1Byb3BzL1BLAQIUAAoAAAAIAGtjrFwYDUZcsAEAADADAAARAAAAAAAAAAAAAAAAAMsXAABkb2NQcm9wcy9jb3JlLnhtbFBLAQIUAAoAAAAIAGtjrFzio178tgIAANgSAAASAAAAAAAAAAAAAAAAAKoZAAB3b3JkL251bWJlcmluZy54bWxQSwECFAAKAAAAAABrY6xcAAAAAAAAAAAAAAAABgAAAAAAAAAAABAAAACQHAAAX3JlbHMvUEsBAhQACgAAAAgAa2OsXB+jkpbmAAAAzgIAAAsAAAAAAAAAAAAAAAAAtBwAAF9yZWxzLy5yZWxzUEsBAhQACgAAAAgAa2OsXKCOjqWaAQAAOAgAABMAAAAAAAAAAAAAAAAAwx0AAFtDb250ZW50X1R5cGVzXS54bWxQSwECFAAKAAAACABrY6xcWHnbIpIAAADkAAAAEwAAAAAAAAAAAAAAAACOHwAAZG9jUHJvcHMvY3VzdG9tLnhtbFBLAQIUAAoAAAAIAGtjrFzi/J3akwAAAOYAAAAQAAAAAAAAAAAAAAAAAFEgAABkb2NQcm9wcy9hcHAueG1sUEsBAhQACgAAAAgAa2OsXJyJyZHOAQAArQYAABIAAAAAAAAAAAAAAAAAEiEAAHdvcmQvZm9vdG5vdGVzLnhtbFBLAQIUAAoAAAAIAGtjrFzSd/y3bQAAAHsAAAAdAAAAAAAAAAAAAAAAABAjAAB3b3JkL19yZWxzL2Zvb3Rub3Rlcy54bWwucmVsc1BLAQIUAAoAAAAIAGtjrFw/So6NwQEAAJIGAAARAAAAAAAAAAAAAAAAALgjAAB3b3JkL2VuZG5vdGVzLnhtbFBLAQIUAAoAAAAIAGtjrFzSd/y3bQAAAHsAAAAcAAAAAAAAAAAAAAAAAKglAAB3b3JkL19yZWxzL2VuZG5vdGVzLnhtbC5yZWxzUEsBAhQACgAAAAgAa2OsXE2fysqhAQAAcwUAABEAAAAAAAAAAAAAAAAATyYAAHdvcmQvc2V0dGluZ3MueG1sUEsBAhQACgAAAAgAa2OsXIuGOcTFAQAAxggAABEAAAAAAAAAAAAAAAAAHygAAHdvcmQvY29tbWVudHMueG1sUEsBAhQACgAAAAgAa2OsXNJ3/LdtAAAAewAAABwAAAAAAAAAAAAAAAAAEyoAAHdvcmQvX3JlbHMvY29tbWVudHMueG1sLnJlbHNQSwECFAAKAAAACABrY6xcY+1e1h0BAABDAwAAEgAAAAAAAAAAAAAAAAC6KgAAd29yZC9mb250VGFibGUueG1sUEsBAhQACgAAAAgAa2OsXNJ3/LdtAAAAewAAAB0AAAAAAAAAAAAAAAAABywAAHdvcmQvX3JlbHMvZm9udFRhYmxlLnhtbC5yZWxzUEsFBgAAAAAWABYAfAUAAK8sAAAAAA==",
      "size" : 12865,
      "hash" : "lVW+O8g3uswHHW0s8kirGXp3hJU=",
      "title" : "Amanda_Alzheimer.docx",
      "creation" : "2028-02-06"
    },
    "format" : {
      "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
      "code" : "urn:ihe:iti:xds:2017:mimeTypeSufficient"
    }
  }],
  "context" : {
    "encounter" : [{
      "reference" : "Encounter/AmandaAlzheimerEinrichtungskontakt"
    }],
    "event" : [{
      "coding" : [{
        "system" : "http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung",
        "code" : "E234"
      }]
    }],
    "period" : {
      "start" : "2028-01-24",
      "end" : "2028-02-06"
    },
    "facilityType" : {
      "coding" : [{
        "system" : "http://ihe-d.de/CodeSystems/PatientBezogenenGesundheitsversorgung",
        "code" : "KHS"
      }]
    },
    "practiceSetting" : {
      "coding" : [{
        "system" : "http://ihe-d.de/CodeSystems/AerztlicheFachrichtungen",
        "code" : "INTZ"
      }]
    }
  }
}

```
