# Home - MII IG Dokument v2026.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ImplementationGuide/mii-ig-dokument | *Version*:2026.0.1 |
| Draft as of 2026-07-23 | *Computable Name*:MII_IG_Dokument |

# MII_IG_Dok_DE

Feel free to modify this index page with your own awesome content!

