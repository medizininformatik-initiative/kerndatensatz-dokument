# de.medizininformatikinitiative.kerndatensatz.dokument#2027.0.0-ballot.rc2: MII IG Dokument(de)

## Pages

* [Startseite](index.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Änderungshistorie](changes.md)
* [Kompatibilität zu anderen Spezifikationen](kompatibilitaet.md)
* [CodeSystems](code-systems.md)
* [Beispiele](examples.md)
* [ValueSets](value-sets.md)
* [CapabilityStatements](capability-statements.md)
* [Artefaktübersicht](artifacts.md)
* [Metadaten-Übersicht](metadata.md)
* [UML-Diagramme](uml-diagrams.md)
* [Übersetzungsinformationen](translationinfo.md)
* [Downloads](downloads.md)
* [Anleitung](guidance.md)
* [Extensions](extensions.md)
* [Profile](profiles.md)
* [Versionierung](version-history.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Logische Modelle](logical-models.md)
* [Suchparameter](search-parameters.md)

## Resources

### CodeSystems

* [ISO 3166-1 Ländercodes (Fragment: Deutschland)](CodeSystem-iso3166-1-fragment.md)
* [ISO 3166-2 Subdivisionscodes (Fragment: Sachsen)](CodeSystem-iso3166-2-fragment.md)
* [MII CS Dokument NLP Processing Status](CodeSystem-mii-cs-dokument-nlp-processing-status.md)
* [UN M49 Regionen (Fragment: Welt, Europa)](CodeSystem-unsd-m49-fragment.md)

### ValueSets

* [MII VS Dokument Einrichtungsart](ValueSet-mii-vs-dokument-einrichtungsart.md)
* [MII VS Dokument Fachgebiet](ValueSet-mii-vs-dokument-fachgebiet.md)
* [MII VS Dokument Format Code](ValueSet-mii-vs-dokument-format-code.md)
* [MII VS Dokument NLP Processing Status](ValueSet-mii-vs-dokument-nlp-processing-status.md)
* [MII VS Dokument SCT Dokument Kategorie](ValueSet-mii-vs-dokument-sct-dokument-kategorie.md)
* [MII VS Dokument SCT Dokument Typ](ValueSet-mii-vs-dokument-sct-dokument-typ.md)

### Logicals

* [MII LM Dokument](StructureDefinition-mii-lm-dokument.md)

### Resource Profiles

* [MII PR Dokument Dokument](StructureDefinition-mii-pr-dokument-dokument.md)

### Extensions

* [MII EX Dokument NLP Processing Status](StructureDefinition-mii-ex-dokument-nlp-processing-status.md)

### CapabilityStatements

* [MII CPS Dokument CapabilityStatement](CapabilityStatement-mii-cps-dokument-capabilitystatement.md)

### ExampleScenarios

* [NlpPipelineAmandaAlzheimer](ExampleScenario-NlpPipelineAmandaAlzheimer.md)

### ImplementationGuides

* [MII IG Dokument](ImplementationGuide-mii-ig-dokument.md)

### Parameters

* [mii-param-dokument-manifest](Parameters-mii-param-dokument-manifest.md)

### Examples

* [AmandaAlzheimerAnnotiertesDokument (DocumentReference)](DocumentReference-AmandaAlzheimerAnnotiertesDokument.md)
* [AmandaAlzheimerDeIdentifiziertesDokument (DocumentReference)](DocumentReference-AmandaAlzheimerDeIdentifiziertesDokument.md)
* [AmandaAlzheimerKlartextDokument (DocumentReference)](DocumentReference-AmandaAlzheimerKlartextDokument.md)
* [AmandaAlzheimerOriginalDokument (DocumentReference)](DocumentReference-AmandaAlzheimerOriginalDokument.md)
* [AmandaAlzheimerAbteilungskontakt (Encounter)](Encounter-AmandaAlzheimerAbteilungskontakt.md)
* [AmandaAlzheimerEinrichtungskontakt (Encounter)](Encounter-AmandaAlzheimerEinrichtungskontakt.md)
* [AmandaAlzheimerVersorgungsstellenKontakt (Encounter)](Encounter-AmandaAlzheimerVersorgungsstellenKontakt.md)
* [AmandaAlzheimer (Patient)](Patient-AmandaAlzheimer.md)
